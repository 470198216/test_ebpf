#ifndef _USDTLIBX_H_
#define _USDTLIBX_H_
extern long myclock();
#endif
